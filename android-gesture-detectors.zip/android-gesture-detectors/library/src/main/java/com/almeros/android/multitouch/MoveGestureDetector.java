package com.almeros.android.multitouch;

import android.content.Context;
import android.graphics.PointF;
import android.util.Log;
import android.view.MotionEvent;
import com.almeros.android.multitouch.BaseGestureDetector;

/**
 * @author Almer Thie (code.almeros.com)
 * Copyright (c) 2013, Almer Thie (code.almeros.com)
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer 
 *  in the documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */
public class MoveGestureDetector extends BaseGestureDetector {
	
	/**
	 * Listener which must be implemented which is used by MoveGestureDetector
	 * to perform callbacks to any implementing class which is registered to a
	 * MoveGestureDetector via the constructor.
	 * 
	 * @see MoveGestureDetector.SimpleOnMoveGestureListener
	 */
	public interface OnMoveGestureListener {
		public boolean onMove(MoveGestureDetector detector);
		public boolean onMoveBegin(MoveGestureDetector detector);
		public void onMoveEnd(MoveGestureDetector detector);
	}
	
	/**
	 * Helper class which may be extended and where the methods may be
	 * implemented. This way it is not necessary to implement all methods
	 * of OnMoveGestureListener.
	 */
	public static class SimpleOnMoveGestureListener implements OnMoveGestureListener {
	    public boolean onMove(MoveGestureDetector detector) {
	        return false;
	    }

	    public boolean onMoveBegin(MoveGestureDetector detector) {
	        return true;
	    }

	    public void onMoveEnd(MoveGestureDetector detector) {
	    	// Do nothing, overridden implementation may be used
	    }
	}

    private static final PointF FOCUS_DELTA_ZERO = new PointF();
    
    private final OnMoveGestureListener mListener;
    
    private PointF mCurrFocusInternal;//internal代表手指頭之間的中心點(prev),這個過程中手指頭數量可能改變,所以用internal,最後用internal來算出來的結果得到external
    private PointF mPrevFocusInternal;//internal代表手指頭之間的中心點(curr)
    private PointF mFocusExternal = new PointF();//代表指頭數量確定後且移動之後的中心點位置
    private PointF mFocusDeltaExternal = new PointF();//external代表internal中心點找好後,前(prev)跟後(curr)internal中心點的平移量
    

    public MoveGestureDetector(Context context, OnMoveGestureListener listener) {
    	super(context);//注意這邊就不需要再this.context = context了,直接super(context)即可
        mListener = listener;
    }

    @Override
    protected void handleStartProgressEvent(int actionCode, MotionEvent event){
        switch (actionCode) { 
            case MotionEvent.ACTION_DOWN: 
                resetState(); // In case we missed an UP/CANCEL event
                
                mPrevEvent = MotionEvent.obtain(event);
                mTimeDelta = 0;

                updateStateByEvent(event);
                break;
            
            case MotionEvent.ACTION_MOVE:
                //第一次的ACTION_MOVE會進來這邊,只做一個動作,把gestureInProgress設true,好讓移動中的動作都進到下面的handleInProgressEvent
                mGestureInProgress = mListener.onMoveBegin(this);//gestureInProgress 來自BaseGestureDetector
                break;
        }
    }
    
    @Override
    protected void handleInProgressEvent(int actionCode, MotionEvent event){ 	
        switch (actionCode) {
        	case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mListener.onMoveEnd(this);//目前是沒做任何動作,保留用的
                resetState();//ACTION_UP或ACTION_CANCEL代表手放掉了,所有的移動已經結束,就用resetState()將gestureInProgress設回false,好讓下一次點擊時又能從handleStartProgressEvent開始
                break;

            case MotionEvent.ACTION_MOVE:
                //第一次之後的所有ACTION_MOVE會進來這邊
                updateStateByEvent(event);//更新移動的中心點

				/* 下面這段是用來更精確的判斷手指按壓狀況,不使用也沒關係
                 * Only accept the event if our relative pressure is within a certain limit.
                 * This can help filter shaky data as a finger is lifted. */
                if (mCurrPressure / mPrevPressure > PRESSURE_THRESHOLD) {
                    final boolean updatePrevious = mListener.onMove(this);
                    if (updatePrevious) {
                        mPrevEvent.recycle();
                        mPrevEvent = MotionEvent.obtain(event);
                    }
                }
                break;
        }
	}

    //如果沒有複寫也可以直接用updateStateByEvent(curr);就會直接使用父方法
    protected void updateStateByEvent(MotionEvent curr) {
    	super.updateStateByEvent(curr);

        //下面是要改寫或擴增的部分
    	final MotionEvent prev = mPrevEvent;
    	
        // Focus intenal
        mCurrFocusInternal = determineFocalPoint(curr);//手指頭之間的中心點
        mPrevFocusInternal = determineFocalPoint(prev);//手指頭之間的中心點
        
        // Focus external
        // - Prevent skipping of focus delta when a finger is added or removed
        boolean mSkipNextMoveEvent = prev.getPointerCount() != curr.getPointerCount();//如果PointerCount不一樣代表增加或減少了手指的數量,沒增減通常得到false
        //前後手指頭數量不一樣就會得到true就代表忽略, 使用FOCUS_DELTA_ZERO也就是指頭有變化的那次就忽略delta,否則就每次計算前後位置
        mFocusDeltaExternal = mSkipNextMoveEvent ? FOCUS_DELTA_ZERO : new PointF(mCurrFocusInternal.x - mPrevFocusInternal.x,  mCurrFocusInternal.y - mPrevFocusInternal.y);

        // - Don't directly use mFocusInternal (or skipping will occur). Add 
        // 	 unskipped delta values to mFocusExternal instead.
        mFocusExternal.x += mFocusDeltaExternal.x;
        mFocusExternal.y += mFocusDeltaExternal.y;
    }

	/**
	 * Determine (multi)finger focal point (a.k.a. center point between all
	 * fingers)
	 * 
	 * @param MotionEvent e
	 * @return PointF focal point
	 */
    //決定手指頭之間的中心點
    private PointF determineFocalPoint(MotionEvent e){
    	// Number of fingers on screen
        final int pCount = e.getPointerCount(); 
        float x = 0f;
        float y = 0f;
        
        for(int i = 0; i < pCount; i++){
        	x += e.getX(i);//x分量加總
        	y += e.getY(i);//y分量加總
        }
        
        return new PointF(x/pCount, y/pCount);//總量除以個數得到平均的x與y值,也就是幾個手指頭的中心點
    }

    public float getFocusX() {
        return mFocusExternal.x;
    }

    public float getFocusY() {
        return mFocusExternal.y;
    }

    //取得先跟後之間中心點的平移量
    public PointF getFocusDelta() {
		return mFocusDeltaExternal;
    }

}
