package com.almeros.android.multitouch.sample;

import android.app.Activity;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import com.almeros.android.multitouch.MoveGestureDetector;
import com.almeros.android.multitouch.RotateGestureDetector;
import com.almeros.android.multitouch.ShoveGestureDetector;

/**
 * Test activity for testing the different GestureDetectors.
 * 
 * @author Almer Thie (code.almeros.com)
 * Copyright (c) 2013, Almer Thie (code.almeros.com)
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer 
 *  in the documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */
public class TouchActivity extends Activity implements OnTouchListener {

	private Matrix mMatrix = new Matrix();//matrix用來控制圖片的scale,translate,rotate
    private float mScaleFactor = .4f;//縮放改變時會更改的參數
    private float mRotationDegrees = 0.f;//旋轉角度改變時會更改的參數
    private float mFocusX = 0.f;//平移時會更改的x參數
    private float mFocusY = 0.f;//平移時會更改的y參數
    private int mAlpha = 255;
    private int mImageHeight, mImageWidth;

    private ScaleGestureDetector mScaleDetector;
    private RotateGestureDetector mRotateDetector;
    private MoveGestureDetector mMoveDetector;
    private ShoveGestureDetector mShoveDetector;

	@SuppressWarnings("deprecation")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		/**
		 * 圖片與螢幕的關係靠的是左上角的座標點, 所以們需要幾個主要的資訊來控制相關位置
		 * 1.螢幕中心點 => (focusX, focusY)
		 * 2.圖片的中心點 => 取得圖片長與寬,再分別取1/2距離,到時候扣掉這段距離就會移到中間
		 * 3.若有scale, 就要乘上 sacle
		 * 4. */
		// 先取得螢幕中心點 Determine the center of the screen to center 'earth'
		Display display = getWindowManager().getDefaultDisplay();
		mFocusX = display.getWidth()/2f;
		mFocusY = display.getHeight()/2f;
		
		// Set this class as touchListener to the ImageView
		ImageView view = (ImageView) findViewById(R.id.imageView);
		view.setOnTouchListener(this);
		
		// Determine dimensions of 'earth' image
		Drawable d 		= this.getResources().getDrawable(R.drawable.earth);
		mImageHeight 	= d.getIntrinsicHeight();//抓圖片現在所呈現的高度
		mImageWidth 	= d.getIntrinsicWidth();//抓圖片現在所呈現的寬度

		// View is scaled and translated by matrix, so scale and translate initially
        float scaledImageCenterX = (mImageWidth*mScaleFactor)/2; 
        float scaledImageCenterY = (mImageHeight*mScaleFactor)/2;
        
		mMatrix.postScale(mScaleFactor, mScaleFactor);
		mMatrix.postTranslate(mFocusX - scaledImageCenterX, mFocusY - scaledImageCenterY);//讓圖片呈現在中心點,所以要做個平移,中心點位置分別減掉水平跟垂直距離的一半
		view.setImageMatrix(mMatrix);

		// Setup Gesture Detectors
		mScaleDetector 	= new ScaleGestureDetector(getApplicationContext(), new ScaleListener());
		mRotateDetector = new RotateGestureDetector(getApplicationContext(), new RotateListener());
		mMoveDetector 	= new MoveGestureDetector(getApplicationContext(), new MoveListener());
		mShoveDetector 	= new ShoveGestureDetector(getApplicationContext(), new ShoveListener());
	}
	
	@SuppressWarnings("deprecation")
	public boolean onTouch(View v, MotionEvent event) {
        mScaleDetector.onTouchEvent(event);
        mRotateDetector.onTouchEvent(event);
        mMoveDetector.onTouchEvent(event);
        mShoveDetector.onTouchEvent(event);

		//重新餵值
        float scaledImageCenterX = (mImageWidth*mScaleFactor)/2;
        float scaledImageCenterY = (mImageHeight*mScaleFactor)/2;
        
        mMatrix.reset();
        mMatrix.postScale(mScaleFactor, mScaleFactor);
        mMatrix.postRotate(mRotationDegrees,  scaledImageCenterX, scaledImageCenterY);
        mMatrix.postTranslate(mFocusX - scaledImageCenterX, mFocusY - scaledImageCenterY);//讓圖片呈現在中心點,所以要做個平移,中心點位置分別減掉水平跟垂直距離的一半
        
		ImageView view = (ImageView) v;
		view.setImageMatrix(mMatrix);
		view.setAlpha(mAlpha);

		return true; // indicate event was handled
	}

	private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
		@Override
		public boolean onScale(ScaleGestureDetector detector) {
			mScaleFactor *= detector.getScaleFactor(); // scale change since previous event
			
			// Don't let the object get too small or too large.
			mScaleFactor = Math.max(0.1f, Math.min(mScaleFactor, 10.0f)); 

			return true;
		}
	}
	
	private class RotateListener extends RotateGestureDetector.SimpleOnRotateGestureListener {
		@Override
		public boolean onRotate(RotateGestureDetector detector) {
			mRotationDegrees -= detector.getRotationDegreesDelta();
			return true;
		}
	}	


	/* 一定會覺得奇怪,MoveListener何不直接實作MoveGestureDetector的介面OnMoveGestureListener就好,
	 * 如下所示,
	 * 其實是可以的,但作者希望想要用到的method再寫出來就好,不用全部一起實作看起來很多餘,所以作者
	 * 在MoveGestureDetector這裡面就先建了一個
	 * public static class SimpleOnMoveGestureListener implements OnMoveGestureListener
	 * 在這一步就先全部實作,然後在現在這邊TouchActivity建一個class MoveListener改用extends的方式,
	 * 而不用implements,這樣的好處是就可以不用全部在TouchActivity寫出來,只要寫出想拿出來用的method
	 * 即可 */
//	private class MoveListener implements MoveGestureDetector.OnMoveGestureListener {
//
//		@Override
//		public boolean onMove(MoveGestureDetector detector) {
//			return false;
//		}
//
//		@Override
//		public boolean onMoveBegin(MoveGestureDetector detector) {
//			return false;
//		}
//
//		@Override
//		public void onMoveEnd(MoveGestureDetector detector) {
//
//		}
//	}

	private class MoveListener extends MoveGestureDetector.SimpleOnMoveGestureListener {
		@Override
		public boolean onMove(MoveGestureDetector detector) {
			PointF d = detector.getFocusDelta();
			mFocusX += d.x;
			mFocusY += d.y;

			 mFocusX = detector.getFocusX();
			 mFocusY = detector.getFocusY();
			return true;
		}
	}		
	
	private class ShoveListener extends ShoveGestureDetector.SimpleOnShoveGestureListener {
		@Override
		public boolean onShove(ShoveGestureDetector detector) {
			mAlpha += detector.getShovePixelsDelta();
			if (mAlpha > 255)
				mAlpha = 255;
			else if (mAlpha < 0)
				mAlpha = 0;
			
			return true;
		}
	}	

}